import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { LineChart, Line, ResponsiveContainer, YAxis } from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Loader2, Wifi, TrendingUp, AlertCircle } from "lucide-react";

// Mock data generation
const generateData = () => {
  return Array.from({ length: 20 }, (_, i) => ({
    time: i,
    value: 1 + Math.random() * 5 + (i > 15 ? Math.random() * 10 : 0),
  }));
};

export function LiveSignal() {
  const [data, setData] = useState(generateData());
  const [prediction, setPrediction] = useState("2.45x");
  const [status, setStatus] = useState<"waiting" | "flying" | "crashed">("waiting");
  const [countdown, setCountdown] = useState(5);

  useEffect(() => {
    const interval = setInterval(() => {
      setData((prev) => {
        const newData = [...prev.slice(1), { time: prev[prev.length - 1].time + 1, value: 1 + Math.random() * 2 }];
        return newData;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    // Simulate game cycle
    const cycle = setInterval(() => {
      setStatus("flying");
      setPrediction(`${(1.5 + Math.random() * 10).toFixed(2)}x`);
      
      setTimeout(() => {
        setStatus("crashed");
        setTimeout(() => {
          setStatus("waiting");
          setCountdown(5);
        }, 3000);
      }, 5000 + Math.random() * 5000);
      
    }, 15000);

    return () => clearInterval(cycle);
  }, []);

  return (
    <Card className="w-full max-w-md mx-auto bg-black/40 backdrop-blur border-primary/20 overflow-hidden relative">
      <div className="absolute inset-0 bg-grid-white/[0.02] -z-10" />
      
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-xl font-display text-primary flex items-center gap-2">
          <Wifi className="h-5 w-5 animate-pulse" />
          LIVE SIGNAL
        </CardTitle>
        <Badge variant={status === "flying" ? "default" : "secondary"} className="uppercase font-mono">
          {status}
        </Badge>
      </CardHeader>
      
      <CardContent className="space-y-6">
        {/* Main Prediction Display */}
        <div className="text-center py-8 relative">
          <div className="absolute inset-0 bg-primary/5 blur-3xl rounded-full" />
          <motion.div
            key={prediction}
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="relative z-10"
          >
            <div className="text-sm text-muted-foreground mb-1 font-mono uppercase tracking-widest">Next Prediction</div>
            <div className="text-6xl font-black font-display text-white tracking-tighter drop-shadow-[0_0_15px_rgba(34,197,94,0.5)]">
              {status === "waiting" ? "WAIT..." : prediction}
            </div>
          </motion.div>
        </div>

        {/* Chart */}
        <div className="h-32 w-full bg-black/20 rounded-lg overflow-hidden border border-white/5 relative">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={data}>
              <YAxis hide domain={[0, 'auto']} />
              <Line 
                type="monotone" 
                dataKey="value" 
                stroke="hsl(var(--primary))" 
                strokeWidth={2} 
                dot={false}
                animationDuration={300}
              />
            </LineChart>
          </ResponsiveContainer>
          
          {/* Overlay Grid */}
          <div className="absolute inset-0 bg-[linear-gradient(90deg,transparent_49%,rgba(255,255,255,0.05)_50%,transparent_51%)] bg-[length:20px_100%]" />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="bg-secondary/50 p-3 rounded border border-white/5">
            <div className="text-xs text-muted-foreground flex items-center gap-1">
              <TrendingUp className="h-3 w-3" /> Accuracy
            </div>
            <div className="text-xl font-bold font-display text-primary">98.4%</div>
          </div>
          <div className="bg-secondary/50 p-3 rounded border border-white/5">
            <div className="text-xs text-muted-foreground flex items-center gap-1">
              <AlertCircle className="h-3 w-3" /> Risk Level
            </div>
            <div className="text-xl font-bold font-display text-yellow-500">LOW</div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
