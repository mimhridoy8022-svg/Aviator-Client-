import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Loader2, Lock, User, Mail, Play, Clock, AlertTriangle } from "lucide-react";
import planeImage from "@assets/generated_images/3d_red_airplane_for_aviator_game.png";

type BotState = "landing" | "login" | "processing" | "result" | "cooldown";

export function BotInterface() {
  const [state, setState] = useState<BotState>("landing");
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [password, setPassword] = useState("");
  const [timeLeft, setTimeLeft] = useState(0);
  const [prediction, setPrediction] = useState("0.00x");
  const [error, setError] = useState("");

  // Timer logic
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    } else if (timeLeft === 0 && state === "processing") {
      showPrediction();
    } else if (timeLeft === 0 && state === "cooldown") {
       showPrediction();
    }
    return () => clearInterval(interval);
  }, [timeLeft, state]);

  const handleStart = () => {
    setState("login");
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !name || !password) {
      setError("সব ফিল্ড পূরণ করুন (Fill all fields)");
      return;
    }
    if (password.length < 4) {
      setError("পাসওয়ার্ড খুব ছোট (Password too short)");
      return;
    }
    setError("");
    
    try {
      const response = await fetch("/api/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, email, password }),
      });
      
      if (!response.ok) {
        setError("সার্ভার এরর। আবার চেষ্টা করুন।");
        return;
      }
      
      startProcessing();
    } catch (err) {
      setError("কানেকশন এরর। আবার চেষ্টা করুন।");
    }
  };

  const startProcessing = () => {
    setState("processing");
    setTimeLeft(60); // 1 minute
  };

  const showPrediction = () => {
    // Generate random realistic multiplier
    const val = (1.00 + Math.random() * 5 + (Math.random() > 0.8 ? Math.random() * 10 : 0)).toFixed(2);
    setPrediction(`${val}x`);
    setState("result");
  };

  const handleNext = () => {
    setState("cooldown");
    setTimeLeft(300); // 5 minutes
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="w-full max-w-md mx-auto min-h-[600px] perspective-1000">
      <AnimatePresence mode="wait">
        {state === "landing" && (
          <motion.div
            key="landing"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 1.1 }}
            transition={{ duration: 0.5 }}
            className="flex flex-col items-center justify-center min-h-[500px] space-y-8"
          >
             <div className="w-32 h-32 bg-primary/20 rounded-full flex items-center justify-center border-4 border-primary/50 animate-[pulse_3s_infinite]">
                <Play className="h-16 w-16 text-primary ml-2" />
             </div>
             <div className="text-center space-y-2">
               <h2 className="text-4xl font-black font-display text-white">AVIATOR BOT</h2>
               <p className="text-lg text-primary font-mono tracking-widest">SYSTEM ONLINE</p>
             </div>
             
             <div className="space-y-4 flex flex-col items-center w-full">
               <Button 
                 onClick={handleStart}
                 className="h-16 px-12 text-2xl font-bold bg-white text-black hover:bg-gray-200 rounded-full shadow-[0_0_40px_rgba(255,255,255,0.3)] hover:scale-105 transition-transform w-full max-w-xs"
               >
                 START BOT
               </Button>
               <p className="text-sm text-muted-foreground animate-pulse text-center px-4">
                 বট চালু করতে উপরের START বাটনে ক্লিক করুন<br/>
                 (Click START to run the bot)
               </p>
             </div>
          </motion.div>
        )}

        {state === "login" && (
          <motion.div
            key="login"
            initial={{ opacity: 0, rotateY: 90 }}
            animate={{ opacity: 1, rotateY: 0 }}
            exit={{ opacity: 0, rotateY: -90 }}
            transition={{ duration: 0.5 }}
          >
            <Card className="bg-black/80 backdrop-blur-xl border-primary/20 shadow-[0_0_50px_rgba(34,197,94,0.1)]">
              <CardContent className="p-8 space-y-6">
                <div className="text-center space-y-2 mb-8">
                  <div className="w-20 h-20 bg-primary/10 rounded-full mx-auto flex items-center justify-center border border-primary/30 mb-4 animate-pulse">
                    <User className="h-10 w-10 text-primary" />
                  </div>
                  <h2 className="text-2xl font-bold font-display text-white">PLAYER LOGIN</h2>
                  <p className="text-sm text-muted-foreground">VIP সিগন্যাল পেতে লগইন করুন</p>
                </div>

                <form onSubmit={handleLogin} className="space-y-4">
                  <div className="space-y-2">
                    <Label className="text-xs uppercase tracking-wider text-primary/80">Player Name</Label>
                    <div className="relative">
                      <User className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                      <Input 
                        placeholder="আপনার নাম লিখুন" 
                        className="pl-9 bg-white/5 border-white/10 focus:border-primary/50 text-white"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label className="text-xs uppercase tracking-wider text-primary/80">Gmail ID</Label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                      <Input 
                        placeholder="example@gmail.com" 
                        className="pl-9 bg-white/5 border-white/10 focus:border-primary/50 text-white"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-xs uppercase tracking-wider text-primary/80">VIP Password</Label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                      <Input 
                        type="password" 
                        placeholder="••••••••" 
                        className="pl-9 bg-white/5 border-white/10 focus:border-primary/50 text-white"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                      />
                    </div>
                  </div>

                  {error && (
                    <div className="text-red-500 text-xs flex items-center gap-1 bg-red-500/10 p-2 rounded">
                      <AlertTriangle className="h-3 w-3" /> {error}
                    </div>
                  )}

                  <Button type="submit" className="w-full h-12 text-lg font-bold bg-primary hover:bg-primary/90 text-primary-foreground shadow-[0_0_20px_rgba(34,197,94,0.3)]">
                    LOGIN NOW
                  </Button>
                </form>
              </CardContent>
            </Card>
          </motion.div>
        )}

        {(state === "processing" || state === "cooldown") && (
          <motion.div
            key="timer"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 1.2 }}
            className="flex flex-col items-center justify-center h-[500px] text-center"
          >
             <div className="relative mb-8">
               <div className="absolute inset-0 bg-primary/20 blur-xl rounded-full animate-pulse" />
               <div className="relative w-48 h-48 rounded-full border-4 border-white/10 flex items-center justify-center bg-black/40 backdrop-blur">
                  <div className="text-5xl font-black font-display text-white tabular-nums">
                    {formatTime(timeLeft)}
                  </div>
                  <svg className="absolute inset-0 w-full h-full -rotate-90">
                    <circle
                      cx="96"
                      cy="96"
                      r="90"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="4"
                      className="text-primary"
                      strokeDasharray={565}
                      strokeDashoffset={565 - (565 * timeLeft) / (state === 'processing' ? 60 : 300)}
                      strokeLinecap="round"
                      style={{ transition: "stroke-dashoffset 1s linear" }}
                    />
                  </svg>
               </div>
             </div>
             
             <h3 className="text-2xl font-bold text-white mb-2 animate-pulse">
               {state === "processing" ? "ANALYZING SERVER..." : "COOLDOWN PERIOD"}
             </h3>
             <p className="text-muted-foreground max-w-xs mx-auto">
               {state === "processing" 
                 ? "Connecting to Aviator database for next guaranteed signal..." 
                 : "Waiting for next safe entry point. Do not trade yet."}
             </p>
          </motion.div>
        )}

        {state === "result" && (
          <motion.div
            key="result"
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -50 }}
            className="relative"
          >
            <Card className="bg-black/90 backdrop-blur-xl border-primary/50 shadow-[0_0_100px_rgba(34,197,94,0.2)] overflow-hidden">
              <div className="absolute top-0 left-0 right-0 bg-primary/20 p-2 text-center border-b border-primary/30">
                <span className="text-primary font-black tracking-[0.2em] text-sm flex items-center justify-center gap-2">
                   <Play className="h-4 w-4 fill-primary" /> 100% SURE TRADE
                </span>
              </div>
              
              <CardContent className="pt-16 pb-8 px-6 text-center">
                {/* 3D Animation Area */}
                <div className="relative w-64 h-64 mx-auto mb-8">
                  {/* Rotating Rings */}
                  <div className="absolute inset-0 rounded-full border-2 border-dashed border-red-500/30 animate-[spin_10s_linear_infinite]" />
                  <div className="absolute inset-4 rounded-full border border-red-500/50 animate-[spin_3s_linear_infinite_reverse]" />
                  
                  {/* Active Red Line Scanner */}
                  <div className="absolute inset-0 rounded-full border-t-4 border-red-600 shadow-[0_0_20px_#dc2626] animate-[spin_2s_linear_infinite]" />
                  
                  {/* Plane */}
                  <div className="absolute inset-0 flex items-center justify-center z-10">
                    <img 
                      src={planeImage} 
                      alt="Aviator Plane" 
                      className="w-48 h-48 object-contain drop-shadow-[0_10px_20px_rgba(0,0,0,0.5)] animate-[bounce_2s_ease-in-out_infinite]" 
                    />
                  </div>
                </div>

                <div className="space-y-2 mb-8 relative z-20">
                  <div className="text-sm text-muted-foreground uppercase tracking-widest">Target Multiplier</div>
                  <div className="text-7xl font-black font-display text-white drop-shadow-[0_0_10px_rgba(255,255,255,0.5)]">
                    {prediction}
                  </div>
                </div>

                <Button 
                  onClick={handleNext}
                  className="w-full h-14 text-xl font-bold bg-white text-black hover:bg-gray-200 rounded-full shadow-[0_0_30px_rgba(255,255,255,0.2)] animate-pulse"
                >
                  NEXT SIGNAL <Clock className="ml-2 h-5 w-5" />
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
