import { motion } from "framer-motion";
import { BotInterface } from "@/components/bot-interface";
import { Button } from "@/components/ui/button";
import { Plane, Zap } from "lucide-react";
import heroBg from "@assets/generated_images/cyberpunk_aviation_radar_interface.png";

export default function Home() {
  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 border-b border-white/5 bg-background/80 backdrop-blur-md">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="h-8 w-8 bg-primary/20 rounded-lg flex items-center justify-center border border-primary/50">
              <Plane className="h-5 w-5 text-primary rotate-[-45deg]" />
            </div>
            <span className="font-display font-bold text-xl tracking-wide">AVIATOR<span className="text-primary">SIGNAL</span></span>
          </div>
          <div className="flex items-center gap-2">
             <div className="h-2 w-2 bg-green-500 rounded-full animate-pulse" />
             <span className="text-xs font-mono text-green-500">SYSTEM ACTIVE</span>
          </div>
        </div>
      </nav>

      {/* Main Interface Section */}
      <section className="relative min-h-screen pt-24 pb-12 px-4 flex flex-col items-center justify-center overflow-hidden">
        {/* Background Overlay */}
        <div className="absolute inset-0 z-0 opacity-30 pointer-events-none">
          <img src={heroBg} alt="Background" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-b from-background via-background/80 to-background" />
        </div>

        <div className="container mx-auto relative z-10 w-full max-w-4xl">
           <div className="text-center mb-10">
              <h1 className="text-4xl md:text-5xl font-bold font-display mb-2 text-white">
                VIP <span className="text-primary">BOT 4.0</span>
              </h1>
              <p className="text-muted-foreground">Premium Signal Generator</p>
           </div>
           
           <BotInterface />
        </div>
      </section>
      
      {/* Footer */}
      <footer className="py-6 border-t border-white/5 text-center text-xs text-muted-foreground bg-black/20 backdrop-blur">
        <p>AVIATOR SIGNAL PP VIP • EST 2025</p>
      </footer>
    </div>
  );
}
